<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use App\ProductsPhoto;
use DB;
class UploadFileController extends Controller {
	    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

   public function index(){
      return view('category/uploadfile');
      
   }
   public function showUploadFile(Request $request){
      $file = $request->file('image');
      $status_Id = Input::get('name');
      $destinationPath = 'uploads';
      $test = $file->move($destinationPath,$file->getClientOriginalName());
      $arrData = array( 
        'product_id'        => $status_Id,
        'filename'  => $test,                      
    );
    DB::table('productsphoto')->insert($arrData);
      return view('category/uploadfile');
   }
}
<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Product;
use Illuminate\Support\Facades\Input;

Route::get('/', function () {
    return view('auth/login');
});

Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
Route::resource('/products','ProductCRUDController');
/*Route::get('/addcategory', 'CategoryController@fileUpload')->name('addcategory');*/
Route::get('/upload', 'UploadController@uploadForm');
Route::post('/uploadSubmit', 'UploadController@uploadSubmit');
Route::get('/uploadfile','UploadFileController@index');
Route::post('/uploadfile','UploadFileController@showUploadFile');

Route::any ( '/search', function () {
	$q = Input::get ( 'q' );
	if($q != ""){
	$product = Product::where ( 'name', 'LIKE', '%' . $q . '%' )->orWhere ( 'details', 'LIKE', '%' . $q . '%' )->paginate (5)->setPath ( '' );
	$pagination = $product->appends ( array (
				'q' => Input::get ( 'q' ) 
		) );
	if (count ( $product ) > 0)
		return view ( 'welcome' )->withDetails ( $product )->withQuery ( $q );
	}
		return view ( 'welcome' )->withMessage ( 'No Details found. Try to search again !' );
} );
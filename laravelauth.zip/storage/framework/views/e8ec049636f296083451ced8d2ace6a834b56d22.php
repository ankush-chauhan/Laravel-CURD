<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel CRUD</title>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link href="<?php echo e('css/ionicons.min.css'); ?>" rel="stylesheet" type="text/css" />
        <!-- Morris chart -->
    <link href="<?php echo e('css/morris/morris.css'); ?>" rel="stylesheet" type="text/css" />
        <!-- jvectormap -->
    <link href="<?php echo e(asset('css/jvectormap/jquery-jvectormap-1.2.2.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- fullCalendar -->
    <link href="<?php echo e(asset('css/fullcalendar/fullcalendar.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- Daterange picker -->
    <link href="<?php echo e(asset('css/daterangepicker/daterangepicker-bs3.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- bootstrap wysihtml5 - text editor -->
    <link href="<?php echo e(asset('css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
    <link href="<?php echo e(asset('css/AdminLTE.css')); ?>" rel="stylesheet" type="text/css" />

</head>
<body class="skin-black">
             <header class="header">
            <a href="#" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
                AdminLTE
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav user-menu">
                         <?php if(Auth::guest()): ?>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="glyphicon glyphicon-user"></i>
                                  <?php else: ?>
                                <span><?php echo e(Auth::user()->name); ?> <i class="caret"></i></span>
                            </a>
            <div class="slideshow" style="display: none;"><a href="<?php echo e(route('logout')); ?>" class="btn btn-default btn-flat"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Logout</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                        </div>
                    <?php endif; ?>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- /. NAV TOP  -->
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <aside class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                     <?php if(Auth::guest()): ?>
                         <?php else: ?>
                         <div class="pull-left image">
                            <img src="<?php echo e(asset('img/avatar5.png')); ?>" class="img-circle" alt="User Image" />
                        </div>
                        <div class="pull-left info">
                            <p>Hello, <?php echo e(Auth::user()->name); ?></p>

                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                        </div>
                        <?php endif; ?>
                    </div>
                    <!-- search form -->
                    <form action="#" method="get" class="sidebar-form">
                        <div class="input-group">
                            <input type="text" name="q" class="form-control" placeholder="Search..."/>
                            <span class="input-group-btn">
                                <button type='submit' name='seach' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="#">
                                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-th"></i> <span>Widgets</span> <small class="badge pull-right bg-green">new</small>
                            </a>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-bar-chart-o"></i>
                                <span>Charts</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="/uploadfile"><i class="fa fa-angle-double-right"></i> Add Category</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Flot</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Inline charts</a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-laptop"></i>
                                <span>UI Elements</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> General</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Icons</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Buttons</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Sliders</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Timeline</a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-edit"></i> <span>Forms</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> General Elements</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Advanced Elements</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Editors</a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-table"></i> <span>Tables</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Simple tables</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Data tables</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-calendar"></i> <span>Calendar</span>
                                <small class="badge pull-right bg-red">3</small>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-envelope"></i> <span>Mailbox</span>
                                <small class="badge pull-right bg-yellow">12</small>
                            </a>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-folder"></i> <span>Examples</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Invoice</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Login</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Register</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Lockscreen</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> 404 Error</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> 500 Error</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i> Blank Page</a></li>
                            </ul>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                  <section class="content-header">
                    <h1>
                        Dashboard
                        <small>Control panel</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Dashboard</li>
                    </ol>
                </section>            
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                    <div class="col-lg-12 ">
                       <div class="content">
                        <!-- Content Area start here -->
                                 <?php echo $__env->yieldContent('content'); ?>
                        <!-- Content Area End here -->
                     </div>
                    </div>
                    </div>
                  <!-- /. ROW  --> 
    </div>
             <!-- /. PAGE INNER  -->
         <!-- /. PAGE WRAPPER  -->
    </div>
    </div>
<footer>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <!-- jQuery UI 1.10.3 -->
        <script src="<?php echo e(asset('js/jquery-ui-1.10.3.min.js')); ?>" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <!-- Morris.js charts -->
        <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="<?php echo e(asset('js/plugins/morris/morris.min.js')); ?>" type="text/javascript"></script>
        <!-- Sparkline -->
        <script src="<?php echo e(asset('js/plugins/sparkline/jquery.sparkline.min.js')); ?>" type="text/javascript"></script>
        <!-- jvectormap -->
        <script src="<?php echo e(asset('js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>" type="text/javascript"></script>
        <!-- fullCalendar -->
        <script src="<?php echo e(asset('js/plugins/fullcalendar/fullcalendar.min.js')); ?>" type="text/javascript"></script>
        <!-- jQuery Knob Chart -->
        <script src="<?php echo e(asset('js/plugins/jqueryKnob/jquery.knob.js')); ?>" type="text/javascript"></script>
        <!-- daterangepicker -->
        <script src="<?php echo e(asset('js/plugins/daterangepicker/daterangepicker.js')); ?>" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="<?php echo e(asset('js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>" type="text/javascript"></script>
        <!-- iCheck -->
        <script src="<?php echo e(asset('js/plugins/iCheck/icheck.min.js')); ?>" type="text/javascript"></script>

        <!-- AdminLTE App -->
        <script src="<?php echo e(asset('js/AdminLTE/app.js')); ?>" type="text/javascript"></script>
        
        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <script src="<?php echo e(asset('js/AdminLTE/dashboard.js')); ?>" type="text/javascript"></script> 
        <script type="text/javascript">
            $( ".user-menu" ).click(function() {
  $('.slideshow').toggle();
});
        </script>
   <div class="footer">
            <div class="row">
                <div class="col-lg-12" >
                    &copy;  2014 icode.com | Developed by: <a href="#" style="color:#fff;" target="_blank">Mohit Rana</a>
                </div>
            </div>
        </div>
</footer>
</html>
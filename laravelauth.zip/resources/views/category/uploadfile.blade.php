@extends('layouts.default')
    @section('content')
      <?php
         echo Form::open(array('url' => '/uploadfile','files'=>'true'));
         echo 'Select the file to upload.';
         echo Form::file('image');
         echo'Enter Category Name:- '. Form::text('name');
         echo "<br>";
         echo Form::submit('Upload File');
         echo Form::close();
    ?>
@endsection

